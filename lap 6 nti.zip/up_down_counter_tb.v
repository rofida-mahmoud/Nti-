`timescale 1ns/1ps
module ud_counter_tb();
parameter width = 4;
    reg clk;
    reg rst_n;
    reg load_enable;
    reg enable;
    reg up_down;
    reg [width-1:0] load_value;
     wire [width-1:0] counter;
     up_down_counter uut1(
        .clk(clk),
        .rst_n(rst_n),
        .load_enable(load_enable),
        .enable(enable),
        .up_down(up_down),
        .load_value(load_value),
        .counter(counter)
     );
     always #5 clk=~clk;
     initial begin
        clk=0;
        rst_n=0;
        load_enable =0;
        enable =0;
        up_down =0;
        load_value =0; #10;
        rst_n =1; #10;
        load_value = 4'b1001;
        load_enable = 1'b1; #10;
        load_enable =1'b0;
        enable=1'b1;
        up_down =1'b1; #10;
        up_down = 1'b0; #15;
        $stop;
     end




endmodule