module binary_7segment(
    input [3:0] binary_in,
    output reg [6:0] segment_out
);
    always @(*) begin
       case (binary_in)
        4'b0000: segment_out = 7'b011_1111;
        4'b0001: segment_out = 7'b000_0110;
        4'b0010: segment_out = 7'b101_1011;
        4'b0011: segment_out = 7'b100_1111;
        4'b0100: segment_out = 7'b110_0110;
        4'b0101: segment_out = 7'b110_1101;
        4'b0110: segment_out = 7'b111_1101;
        4'b0111: segment_out = 7'b000_0111;
        4'b1000: segment_out = 7'b111_1111;
        4'b1001: segment_out = 7'b110_1111;
        4'b1010: segment_out = 7'b111_0111;
        4'b1011: segment_out = 7'b111_1100;
        4'b1100: segment_out = 7'b011_1001;
        4'b1101: segment_out = 7'b101_1110;
        4'b1110: segment_out = 7'b111_1001;
        4'b1111: segment_out = 7'b111_0001;
        default: begin
            segment_out = 7'b000_0000;
        end
       endcase 
    end
endmodule