module clk_div #(parameter div = 16) (
   input clk_in,
   input rst_n,
   output clk_out
);
   localparam width = $clog2(div) ;
   reg [width -1 :0] counter;
   always @(posedge clk_in or negedge rst_n) begin
     if (! rst_n ) begin
        counter <= {width{1'b0}};
     end
     else begin
        counter <= counter + 1'b1;
     end
   end
   assign clk_out = counter [width-1];
endmodule