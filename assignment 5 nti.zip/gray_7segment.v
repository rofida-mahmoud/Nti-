module gray_7segment(
    input [3:0] gray_in,
    output  [3:0] binary_out,
    output  [6:0] segment_out
);
    gray_binary_behavioral dut(
      .data_in(gray_in),
      .data_out(binary_out)
    );
    binary_7segment dut1 (
        .binary_in(binary_out),
        .segment_out(segment_out)
    );
endmodule