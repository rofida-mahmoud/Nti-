module ram (
   input clk,
   input reset ,
   input w_r,
   input [15:0] wr_data,
   input [8:0] wr_addr,
   input [8:0] rd_addr1,
   input [8:0] rd_addr2,
   output reg [15:0] rd_data1,
   output reg [15:0] rd_data2
);
   reg [15:0] Ram [0:511];
   integer i;
   always @(posedge clk) begin
       if (reset) begin
        rd_data1 <= 16'b0;
        rd_data2 <= 16'b0;
        for ( i=0; i<512; i=i+1) begin
          Ram[i]<=0;  
        end
       end
       else begin
        if (w_r) begin
            Ram[wr_addr] <= wr_data;
        end 
        else begin
        rd_data1 <= Ram[rd_addr1];
        rd_data2 <= Ram[rd_addr2];
        end 
         
         
       
       end
   end
endmodule