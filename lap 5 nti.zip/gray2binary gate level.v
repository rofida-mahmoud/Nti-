module gray_binary_gate_level(
    input [3:0] data,
    output [3:0] out
);
    wire [2:0]x;
    xor u0 (x[0],data[1],data[0]);
    xor u1 (x[1],data[2],data[1]);
    xor u2 (x[2],data[3],data[2]);
    assign out={data[3],x};
endmodule