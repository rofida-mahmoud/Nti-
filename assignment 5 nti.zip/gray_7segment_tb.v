module g2segment_tb();
   reg [3:0] gray_in;
   wire [3:0] binary_out;
   wire [6:0] segment_out;
   integer i;
   gray_7segment uut (
    .gray_in(gray_in),
    .binary_out(binary_out),
    .segment_out(segment_out)
   );
   initial begin
     for ( i=0; i<5; i=i+1) begin
       gray_in = $random; #10; 
     end
   end
endmodule