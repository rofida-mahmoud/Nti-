module shift_register_right(
    input clk,
    input rst_n,
    input serial_in,
    output reg [3:0] shift_out
);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)
        shift_out <= 4'b1000;
        else begin
            shift_out <= {serial_in,shift_out[3:1]};
        end
    end
endmodule