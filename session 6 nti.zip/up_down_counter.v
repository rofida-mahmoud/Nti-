module up_down_counter #(
    parameter width = 4
) (
    input clk,
    input rst_n,
    input enable,
    input up_down,
    output reg [width-1 :0] counter

);
always @(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
    counter <= {width{1'b0}};
   end 
   else if (enable) begin
     if (up_down) begin
        counter <= counter +1'b1;
     end
     else begin
        counter <= counter - 1'b1;
     end
   end
end
    
endmodule