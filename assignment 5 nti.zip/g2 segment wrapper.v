module gray_7segment_wrapper(
    input [3:0] gray_in,
    output  [3:0] binary_out,
    output  [6:0] segment_out
);
gray_binary_behavioral uut3(
    .data_in(~gray_in),
    .data_out(binary_out)
);
binary_7segment uut4(
    .binary_in(binary_out),
    .segment_out(~ segment_out)
);
    
endmodule