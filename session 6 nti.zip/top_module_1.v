module top_module_1(
    input clk_in,
    input rst_n,
    input enable,
    input up_down,
    output [6:0] segment_out
);
wire clk_divider;
wire [3:0] counter_out ;

clk_div dut4(
    .clk_in(clk_in),
    .rst_n(rst_n),
    .clk_out(clk_divider)
);
up_down_counter #(.width(4)) dut5(
   .clk(clk_divider),
   .rst_n(rst_n),
   .enable(enable),
   .up_down(up_down),
   .counter(counter_out)
);
binary_7segment dut6(
    .binary_in(counter_out),
    .segment_out(segment_out)
);
    
endmodule