module clk_div_tb();
   reg rst_n;
   reg clk_in;
   wire clk_out ;
   clk_div #(.div(4))  dut2(
    .rst_n(rst_n),
    .clk_in(clk_in),
    .clk_out(clk_out)
   );
   initial begin
    clk_in =0 ;
    forever #10 clk_in = ~clk_in;
   end
   initial begin
    rst_n =0 ; #10;
    rst_n =1; #100 ; 
    
    $stop;
   end
endmodule