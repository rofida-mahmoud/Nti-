module top_module_2(
   input clk_in,
   input  rst_n,
   input hold_n,
   output wire [3:0] shift_out,
   output wire [3:0] leds 
);
wire clock_div;
clk_div dut_c(
    .clk_in(clk_in),
    .rst_n(rst_n),
    .clk_out(clock_div)
);
shift_register shift(
    .clk(clock_div),
    .rst_n(rst_n),
    .hold_n(hold_n),
    .shift_out(shift_out),
    .leds(leds)
);

endmodule