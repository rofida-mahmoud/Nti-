module up_down_counter_tb();
   parameter width =4;
    reg clk;
    reg rst_n;
    reg enable;
    reg  up_down;
    wire [width-1 :0] counter ;
    
    up_down_counter  dut3(
       .clk(clk),
       .rst_n(rst_n),
       .enable(enable),
       .up_down(up_down),
       .counter(counter)
    );
    initial begin
        clk =0;
        forever #5 clk = ~clk;
    end
    initial begin
        rst_n =0; #10;
        rst_n =1;
        enable = 1'b1; up_down= 1'b1; #10;
        enable = 1'b1; up_down= 1'b0; #10;
        $stop;
    end 

endmodule