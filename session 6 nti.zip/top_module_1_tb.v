module top_module_1_tb ();
     reg clk_in;
    reg rst_n;
    reg enable;
    reg up_down;
    wire [6:0] segment_out;
    integer i;
    top_module_1 uut3(
        .clk_in(clk_in),
        .rst_n(rst_n),
        .enable(enable),
        .up_down(up_down),
        .segment_out(segment_out)
    );
    initial begin
        clk_in =0;
        forever #5  clk_in= ~clk_in;
        end
    initial begin
        rst_n =0 ; 
        enable =1'b0 ; #10;
        rst_n = 1;
        for ( i=0; i<10; i=i+1) begin
            enable= $random;
            up_down= $random; #10;
        end
        $stop;
    end   
endmodule