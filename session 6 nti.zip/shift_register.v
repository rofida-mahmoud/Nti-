module shift_register(
    input clk,
    input rst_n,
    input hold_n,
    output reg [3:0] shift_out,
    output wire [3:0] leds
);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift_out <= 4'b1000;
        end
        else if (hold_n) begin
            shift_out <= {shift_out[0],shift_out[3:1]};
        end
    end
    assign  leds = ~ shift_out;
endmodule