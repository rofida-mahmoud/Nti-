module ram_tb ();
   reg clk;
   reg reset ;
   reg w_r;
   reg [15:0] wr_data;
   reg [8:0] wr_addr;
   reg [8:0] rd_addr1;
   reg [8:0] rd_addr2;
   wire [15:0] rd_data1;
   wire [15:0] rd_data2;
   integer i;
   ram rmm(
    .clk(clk),
    .reset(reset),
    .w_r(w_r),
    .wr_data(wr_data),
    .wr_addr(wr_addr),
    .rd_addr1(rd_addr1),
    .rd_addr2(rd_addr2),
    .rd_data1(rd_data1),
    .rd_data2(rd_data2)
   );
   initial begin
    clk =0;
    forever #5 clk= ~clk;
   end
   initial begin
    reset=1; 
    w_r = 0;
    wr_data= 0;
    wr_addr = 0;
    rd_addr1 = 0;
    rd_addr2 =0;
    #20;
    reset=0;
    @(negedge clk)
    w_r=1;
    wr_addr=9'b0_1001_1010;
    wr_data=16'h7543;
    @(negedge clk)
    w_r=1;
    wr_addr=9'b0_1001_1110;
    wr_data=16'h7CA3;
    @(negedge clk)
    w_r=0;
    rd_addr1=9'b0_1001_1110;
    rd_addr2=9'b0_1001_1110; #20;

    $stop;
   end
endmodule