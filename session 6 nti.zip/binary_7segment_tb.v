module b2segment_tb();
 reg [3:0] binary_in;
 wire [6:0] segment_out;
 integer i;
 binary_7segment uut1(
    .binary_in(binary_in),
    .segment_out(segment_out)
 );
 initial begin
    for ( i=0; i<5; i=i+1) begin
       binary_in = $random; #5; 
    end
    end
endmodule