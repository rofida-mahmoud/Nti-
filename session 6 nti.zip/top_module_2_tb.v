module top_module_2_tb();
   reg clk_in;
   reg  rst_n;
   reg hold_n;
   wire [3:0] shift_out;
   wire [3:0] leds  ;
   integer i;
   top_module_2 top(
    .clk_in(clk_in),
    .rst_n(rst_n),
    .hold_n(hold_n),
    .shift_out(shift_out),
    .leds(leds)
   );
   initial begin
    clk_in=0;
    forever #5 clk_in= ~clk_in;
   end
   initial begin
    rst_n=0; #10;
    rst_n =1;
    for ( i=0; i<10; i=i+1) begin
        hold_n = $random; #100;

    end
   $stop;
   end

endmodule