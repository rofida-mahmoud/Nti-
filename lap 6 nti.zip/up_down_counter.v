module up_down_counter #(
    parameter width = 4
) (
    input clk,
    input rst_n,
    input load_enable, enable, up_down,
    input [width-1:0] load_value,
    output reg [width-1:0] counter
);
    always @(posedge clk or negedge rst_n) begin
       if (!rst_n) begin
        counter <= 0;
       end 
       else if (load_enable) begin
          counter <= load_value;
         end
        else if (enable) begin
            if (up_down) begin
                counter <= load_value +1;
            end else begin
                counter <= load_value -1;
            end
        end 
    
    end
endmodule
    
