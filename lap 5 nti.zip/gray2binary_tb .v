module gray_binary_tb();
    reg [3:0] data_in;
    wire [3:0]data_out; 
   
 integer i;
 gray_binary_behavioral dut(
    .data_in(data_in),
    .data_out(data_out)
 );
 initial begin
    for ( i=0; i<5; i=i+1) begin
        data_in =$random; #5;
    end
 end
endmodule