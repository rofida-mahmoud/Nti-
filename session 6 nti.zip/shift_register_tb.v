module shift_register_tb();
    reg clk;
    reg rst_n;
    reg hold_n;
    wire [3:0] shift_out;
    wire [3:0] leds;
    integer i;
    shift_register uut4(
        .clk(clk),
        .rst_n(rst_n),
        .hold_n(hold_n),
        .shift_out(shift_out),
        .leds(leds)
    ) ;
    initial begin
        clk = 0;
        forever #10 clk =~clk;
    end
    initial begin
        rst_n =0; hold_n=1'b0; @(negedge clk);
        rst_n =1; 
        for ( i=0; i<10; i=i+1) begin
            hold_n = $random; 
             @(negedge clk);
        end
        $stop;
    end

endmodule