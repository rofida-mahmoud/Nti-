module shift_register_right_tb();
    reg clk;
    reg rst_n;
    reg serial_in;
     wire [3:0] shift_out;
     integer i ;
    shift_register_right dut (
        .clk(clk), 
        .rst_n(rst_n),
        .serial_in(serial_in),
        .shift_out(shift_out)
    );
    initial begin
        clk = 0;
        forever #5 clk=~clk ;
    end
    initial begin
        rst_n =0 ;
        serial_in=0;#10;
        rst_n =1; 
        for ( i=0; i<4; i=i+1) begin
            @(negedge clk);
            serial_in = shift_out [0];
        end
       $stop;
    end 
endmodule